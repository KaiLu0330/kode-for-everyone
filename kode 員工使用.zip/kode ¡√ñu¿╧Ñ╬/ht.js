/*function click(){
    alert("登入失敗");
}
function click2(){
    alert("登入失敗");
}
function find(){
    alert("error");
}*/
var btn=document.getElementById("btn");
btn.addEventListener("click",function(){
    alert("登入失敗")
})
var btn2=document.getElementById("btn2");
btn.addEventListener("click",function(){
    alert("註冊失敗")
})
var btn3=document.getElementById("btn3");
btn.addEventListener("click",function(){
    alert("error")
})